// JavaScriptで1-100までをコンソールに出力する
// プログラムを作ってください
for (let i = 1; i <= 100; i++) {
    console.log(i);
}