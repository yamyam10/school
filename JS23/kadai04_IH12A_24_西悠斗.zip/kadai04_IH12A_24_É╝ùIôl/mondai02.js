// JavaScriptで10-39までをコンソールに出力する
// プログラムを作ってください。
for (let i = 10; i <= 39; i++) {
    console.log(i);
}